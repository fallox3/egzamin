<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zadania na lipiec</title>
    <link rel="stylesheet" href="styl6.css">
</head>
<body>
    <div class="baner1">
        <img src="logo1.png" alt="lipiec">
    </div>
    <div class="baner2">
        <h1>TERMINARZ</h2>
        <p>najbliższe zadania:
        <?php
        $db=mysqli_connect("localhost","root","","terminarz");
        $sql="Select distinct wpis from zadania where dataZadania<'2020-07-08' and dataZadania>'2020-07-00'";
        $query=mysqli_query($db,$sql);
        while($row=mysqli_fetch_array($query)){
            echo"$row[0]; ";
        }
        mysqli_close($db);
        ?></p>
    </div>
    <div class="glowny">
        <?php
        $db=mysqli_connect("localhost","root","","terminarz");
        $sql="Select dataZadania,wpis from zadania where miesiac='lipiec'";
        $query=mysqli_query($db,$sql);
        while($row=mysqli_fetch_array($query)){
            echo"<div class='dzien'>
            <h5>$row[0]</h5>
            <p> $row[1]</p>
            </div>";
        }
        
        ?>
    </div>
    <div class="stopka">
        <a href="sierpien.html">Terminarz na sierpień</a>
        <p>Stronę wykonał: 0000000000000</p>
    </div>
</body>
</html>



<?php
    mysqli_close($db);
?>